# ansible
Ansible scripts for configuring a Boa-like cluster
