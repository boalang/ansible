1) Run main-menu.sh as sudo from master node
2) User should have an account with sudo privileges on each node
3) The file slaves.txt can have either ip addresses or hostnames, although hostnames are preferred for working with Hadoop.
